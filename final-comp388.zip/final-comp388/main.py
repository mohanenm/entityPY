import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.preprocessing import LabelEncoder
# albert, add the libraries
from sklearn.metrics import classification_report
from sklearn.base import BaseEstimator, TransformerMixin
import math
import warnings

with warnings.catch_warnings():
    warnings.filterwarnings("ignore",category=DeprecationWarning)
    from sklearn.cross_validation import cross_val_predict

# ethan and tom, add the actual splitting of data tonight
def splitData(words,tags): ## in these down trodding columns these are us testing training, tuning, etc. We train on a few parameters such as max depth and n estimators.
    trainWords=words[0:math.floor((len(words)-1)*.70)]
    trainTags=tags[0:math.floor((len(tags)-1)*.70)]
    validateWords=words[math.floor((len(words)-1)*.7):math.floor((len(words)-1)*.7+(len(words)-1)*.15)]
    validateTags=tags[math.floor((len(tags)-1)*.7):math.floor((len(tags)-1)*.7+(len(tags)-1)*.15)]
    testWords=words[math.floor((len(tags)-1)*.7+(len(tags)-1)*.15):]
    testTags=tags[math.floor((len(tags)-1)*.7+(len(tags)-1)*.15):]
    return trainWords,trainTags,validateWords,validateTags,testWords,testTags
# to make sure we get these warnings: -albert
def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn
def main():
    # stored in the zip as second step
    pandaDf= pd.read_csv("second_step_data.csv") ##Reading in the raw data set using pandas dataframe
    pandaDf= pandaDf.fillna(method="ffill") ## filling in possible empty slots with 0
    ##wordList = list(set(pandadf["Word"].values))
    sentenceNumber=1 ## in getting specific sentences we need to keep track of sentence number
    sentenceSpecificdf = pandaDf[pandaDf["Sentence #"] == "Sentence: {}".format(sentenceNumber)]
    sentence=sentenceSpecificdf["Word"].values.tolist()
    wordList=pandaDf["Word"].values.tolist()
    partOfSpeech=sentenceSpecificdf["POS"].values.tolist()
    tag=sentenceSpecificdf["Tag"].values.tolist()
    words = [np.array([w.istitle(), w.islower(), w.isupper(), len(w),w.isdigit(),  w.isalpha()]) for w in pandaDf["Word"].values.tolist()] ## these are the features we pass to our random forest to train
    tags = pandaDf["Tag"].values.tolist()
    tagger = Memorization()
    # baseline is above, some below
    # notify tom before changes to the baseline
    pred = cross_val_predict(estimator=Memorization(), X=wordList, y=tags, cv=5)
    report = classification_report(y_pred=pred, y_true=tags)
    print("Sci kit learns cross validate predict results \n",report)
    trainWords,trainTags,validateWords,validateTags,testWords,testTags=splitData(words,tags)
    twentytrees = RandomForestClassifier(n_estimators=20)
    fifteentrees=RandomForestClassifier(n_estimators=15)
    onetree=RandomForestClassifier(n_estimators=1)
    fiftytrees=RandomForestClassifier(n_estimators=50)
    # albert, why are we manually validating - enm
    onehundredtrees=RandomForestClassifier(n_estimators=100)
    depth1 = RandomForestClassifier(max_depth=1,n_estimators=20)
    depth2=RandomForestClassifier(max_depth=2,n_estimators=20)
    depth3=RandomForestClassifier(max_depth=3,n_estimators=20)
    depth4=RandomForestClassifier(max_depth=4,n_estimators=20)
    depth5=RandomForestClassifier(max_depth=5,n_estimators=20)
    ##Creating our classifier
    clf20=twentytrees.fit(words,tags)
    clf1=onetree.fit(words,tags)
    clf15=fifteentrees.fit(words,tags)
    clf50=fiftytrees.fit(words,tags)
    clf100=onehundredtrees.fit(words,tags)
    clfdepth2=depth2.fit(words,tags)
    clfdepth1=depth1.fit(words,tags)
    clfdepth3=depth3.fit(words,tags)
    clfdepth4=depth4.fit(words,tags)
    clfdepth5=depth5.fit(words,tags)
    ##predicting
    pred20=clf20.predict(validateWords)
    pred15=clf15.predict(validateWords)
    pred100=clf100.predict(validateWords)
    pred1=clf1.predict(validateWords)
    pred50=clf50.predict(validateWords)
    preddepth2=clfdepth2.predict(validateWords)
    preddepth3=clfdepth3.predict(validateWords)
    preddepth5=clfdepth5.predict(validateWords)
    preddepth1=clfdepth1.predict(validateWords)
    preddepth4=clfdepth4.predict(validateWords)
    ##creating report
    report50 = classification_report(y_pred=pred50, y_true=validateTags)
    report100 = classification_report(y_pred=pred100, y_true=validateTags)
    report20 = classification_report(y_pred=pred20, y_true=validateTags)
    report1 = classification_report(y_pred=pred1, y_true=validateTags)
    report15 = classification_report(y_pred=pred15, y_true=validateTags)
    reportdepth4 = classification_report(y_pred=preddepth4, y_true=validateTags)
    reportdepth5 = classification_report(y_pred=preddepth5, y_true=validateTags)
    reportdepth2 = classification_report(y_pred=preddepth2, y_true=validateTags)
    reportdepth1 = classification_report(y_pred=preddepth1, y_true=validateTags)
    reportdepth3 = classification_report(y_pred=preddepth3, y_true=validateTags)
    print("50 trees\n", report50)
    print("100 trees\n",report100)
    print("20 trees\n",report20)
    print("1 trees\n",report1)
    print("15 trees\n",report15)
    print("4 depth with 20 trees\n",reportdepth4)
    print("5 depth with 20 trees\n",reportdepth5)
    print("2 depth with 20 trees\n",reportdepth2)
    print("1  depth with 20 trees\n",reportdepth1)
    print("3 depth with 20 trees\n", reportdepth3)
    ## Besst result is 100 trees with default depth so we will use that for test
    predtest100=clf100.predict(testWords)
    reportTest=classification_report(y_pred=predtest100, y_true=testTags)
    print("Test set with 100 trees\n", reportTest)
    

# Ethan, Albert, I implemented the BL as a class here - tom
class Memorization(BaseEstimator, TransformerMixin):
    def fit(self, word, labels): ## the method to fit data 
        worddict = {}
        self.labels = []
        for singleword, label in zip(word, labels): 
            if label not in self.labels:
                self.labels.append(label)
            if singleword in worddict:
                if label in worddict[singleword]:
                    worddict[singleword][label] += 1
                else:
                    worddict[singleword][label] = 1
            else:
                worddict[singleword] = {label: 1}
        self.toreturn = {}
        for x, y in worddict.items():
            self.toreturn[x] = max(y, key=y.get)
    
    def predict(self, words, y=None):## method which will predict our results
        return [self.toreturn.get(word, 'O') for word in words]   
    
main()

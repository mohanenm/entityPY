fileReader = open("raw_spanish_training_data.txt",'r')
fileWriter = open("finalized_data.csv",'w')

# not our actual tagging algorithm

fileWriter.write("Sentence #,Word,POS,Tag\n")
lines = fileReader.readlines()
numSentence = 1
newSentence = True
for line in lines:
	data_line = ""
	if "," not in line:
		if line == "\n":
			newSentence = True
		else:
			if(newSentence):
				newSentence = False
				data_line = "Sentence: " + str(numSentence) + ","
				numSentence += 1
			else:
				data_line = ","
			line = line.strip('\n')
			line = line.split(" ")
			line = ",".join(line) + "\n"
			data_line += line
			fileWriter.write(data_line)
fileWriter.close()
